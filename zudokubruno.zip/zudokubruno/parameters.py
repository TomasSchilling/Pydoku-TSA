WHITE = (255,255,255)
LIGHT_GRAY = (200,200,200)
GRAY = (150,150,150)
DARK_GRAY = (90,90,90)
BLACK = (0,0,0)


screen_size = (800,600)
square_size = 66