import random

for i in range(10):
    print(random.randint(0,2))